============================================================
PANDUAN CEPAT DEPLOY KE CPANEL - GEPEKRIS TRETES
============================================================

1. Login ke cPanel Anda (contoh: https://namadomain.com:2083)
2. Buka File Manager -> masuk ke folder public_html/
3. Upload file 'cpanel_deploy.zip' ini ke dalam folder public_html/
4. Klik kanan pada file 'cpanel_deploy.zip' di File Manager cPanel -> pilih 'Extract' (ekstrak di dalam public_html/)
5. Pastikan folder data/ memiliki permission/CHMOD 755 (atau 777)
6. Buka website di domain Anda.
7. Login Admin di menu 'Akses Pengurus' paling bawah footer (kata sandi bawaan: admin123).
8. Klik tombol hijau 'Publikasikan ke Hosting' di atas panel admin untuk memastikan sinkronisasi.

Selesai! Seluruh konten website kini tersimpan permanen di server hosting cPanel Anda dan dapat dilihat oleh semua orang secara real-time.
